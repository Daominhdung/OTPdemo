package com.starter.springboot.enumeration;

public enum AuthorityName {
    ROLE_USER, ROLE_ADMIN
}
